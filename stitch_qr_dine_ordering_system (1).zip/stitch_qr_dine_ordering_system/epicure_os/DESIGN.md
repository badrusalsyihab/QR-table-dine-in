---
name: Epicure OS
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#bbcabf'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#86948a'
  outline-variant: '#3c4a42'
  surface-tint: '#4edea3'
  primary: '#4edea3'
  on-primary: '#003824'
  primary-container: '#10b981'
  on-primary-container: '#00422b'
  inverse-primary: '#006c49'
  secondary: '#ffb95f'
  on-secondary: '#472a00'
  secondary-container: '#ee9800'
  on-secondary-container: '#5b3800'
  tertiary: '#c0c1ff'
  on-tertiary: '#1000a9'
  tertiary-container: '#9699ff'
  on-tertiary-container: '#1d17b2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ffbbe'
  primary-fixed-dim: '#4edea3'
  on-primary-fixed: '#002113'
  on-primary-fixed-variant: '#005236'
  secondary-fixed: '#ffddb8'
  secondary-fixed-dim: '#ffb95f'
  on-secondary-fixed: '#2a1700'
  on-secondary-fixed-variant: '#653e00'
  tertiary-fixed: '#e1e0ff'
  tertiary-fixed-dim: '#c0c1ff'
  on-tertiary-fixed: '#07006c'
  on-tertiary-fixed-variant: '#2f2ebe'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.25rem
  gutter-sm: 0.75rem
  gutter-lg: 2rem
  margin: 1.5rem
  margin-mobile: 1rem
  margin-desktop: 2.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
---

## Brand & Style

This design system drives a mission-critical, high-tempo SaaS operations platform and on-table ordering interface for modern restaurants. The aesthetic balances architectural precision with hospitality warmth, drawing from **Corporate / Modern minimalism** paired with subtle **Glassmorphic and Tonal Layering**.

### Brand Personality & Emotional Response
- **Operational Clarity:** High legibility under varied lighting conditions (dim dining rooms, bright kitchen pass displays, midday patio glare).
- **Vibrant Hospitality:** Inviting, mouth-watering accents that signal freshness, table turnaround, and revenue momentum without overwhelming operational focus.
- **Velocity & Trust:** Snappy, low-latency sensory cues giving front-of-house managers, waitstaff, and diners complete confidence in order placement, ticket routing, and split-bill settlements.

### Design Principles
1. **Status at a Glance:** Status states (table turnover, kitchen fires, item 86-ing) take visual precedence through calibrated, luminous color badges rather than visual clutter.
2. **Tactile Ergonomics:** Hit targets prioritize touch-screen handheld POS devices and diner mobile browsers while scaling to dense 24-inch kitchen and host station displays.
3. **Structured Density:** Information density is grouped by functional zones using low-contrast surface contrast and crisp 1px borders rather than heavy drop shadows.

## Colors

The palette leverages a dark-first foundation designed to minimize eye fatigue during long hospitality shifts and blend seamlessly into dimly lit dining rooms. High-clarity chromatic accents convey order states, culinary energy, and platform actions.

### Core Roles
- **Primary (`#10b981` Emerald):** Represents freshness, completed tickets, active tables, success validations, and revenue-positive CTAs.
- **Secondary (`#f59e0b` Amber):** Signals attention, pending orders, table seating delays, modifier callouts, and warning thresholds.
- **Tertiary (`#6366f1` Indigo):** Dedicated to platform controls, multi-course dining coordination, split checks, and administrative analytics.
- **Neutral (`#0f172a` Deep Slate):** The root background canvas, layered upward into `#1e293b` (surface container) and `#334155` (surface strokes).

### Semantic & Operational Mapping
- **Canvas Base:** `#0f172a` (Root canvas)
- **Surface Elevation 1:** `#1e293b` (Cards, sidebars, modals)
- **Surface Elevation 2:** `#334155` (Hover states, table grid tiles, input fields)
- **Text Primary:** `#f8fafc` (Headings, critical data, item titles)
- **Text Muted:** `#94a3b8` (Subtitles, timestamp intervals, secondary modifiers)
- **Danger / 86'd Alert:** `#ef4444` (Out-of-stock items, voided tickets, emergency kitchen holds)
- **Light Mode Adaptation:** When toggled for guest-facing QR mobile menus or outdoor patio tablets, the foundation flips to `#f8fafc` (Canvas), `#ffffff` (Cards), with `#0f172a` for primary typography.

## Typography

The typographic hierarchy couples **Plus Jakarta Sans** for headlines and structural markers with **Inter** for data grids, dense order ticket streams, and input fields.

- **Plus Jakarta Sans** lends a geometric, welcoming presence to table numbers, category titles, total amounts, and guest-facing digital menus.
- **Inter** ensures zero ambiguity in high-stress order fulfillment. It displays tabular figures (`tnum`) across check balances, countdown timers, quantity tallies, and bill breakdowns.
- High-contrast letterforms guarantee instant legibility when reading order status queues from across an Expo station or kitchen counter.

## Layout & Spacing

The layout is built around a structured **12-column fluid grid** for management consoles, collapsing to a **6-column grid** on tablets (waitstaff stations and POS terminals) and a **4-column fluid layout** for diner-facing mobile web orders.

### Breakpoints & Adaptations
- **Mobile (< 640px):** Single-column stacked order sheets, sticky bottom-sheet checkout bar, fixed top header with active table pill, 16px outer margin.
- **Tablet (641px - 1024px):** Split-view layouts. Left rail: live floor plan or ticket stream (40%). Right rail: table details, split checks, and course controls (60%).
- **Desktop (> 1025px):** 12-column system accommodating persistent micro-navigation (64px collapsed), secondary context tree (280px), live floor map / menu builder (fluid), and contextual order action drawer (360px).

### Spacing Cadence
- Rely on strict 4px/8px incremental rhythm (`0.25rem` to `3rem`).
- Spacing inside data tables and ticket lanes uses compact vertical padding (`space-xs` to `space-sm`) to maximize visible orders per viewport.
- Touch surfaces for POS table buttons maintain a minimum 48px square clearance using `space-md` internal padding.

## Elevation & Depth

Visual hierarchy uses **tonal layering** and **low-contrast outlines** over heavy drop shadows. This preserves crispness on high-brightness kitchen screens and avoids muddy contrasts in dark dining room conditions.

### Tier Structure
- **Level 0 (Canvas Base):** Deep Slate (`#0f172a`). Flat, absorbing background.
- **Level 1 (Surface / Standard Cards):** Slate Container (`#1e293b`) with a 1px structural border of `rgba(255, 255, 255, 0.08)`.
- **Level 2 (Active Table Cards & Sticky Panels):** `#243248` with a 1px border of `rgba(255, 255, 255, 0.12)`. Supported by a subtle ambient shadow: `0 8px 24px -4px rgba(0, 0, 0, 0.35)`.
- **Level 3 (Modals, Slide-over Checkouts, Flyouts):** High-density backdrop blur (`backdrop-filter: blur(12px)`) using `rgba(30, 41, 59, 0.85)` surface fill, 1px border of `rgba(255, 255, 255, 0.18)`, and a diffuse directional shadow: `0 20px 32px -8px rgba(0, 0, 0, 0.5)`.

### Ambient Glows for Critical States
- Active/Urgent table updates use a soft 12px outer glow tinted to the semantic color (e.g., `#10b981` at 20% opacity for ready orders; `#f59e0b` at 25% opacity for summons/needs attention).

## Shapes

The design system employs **Level 2 (Rounded)** shape geometry (`0.5rem` / `8px` base curve), offering an approachable hospitality feel balanced with SaaS organization.

- **Standard Containers & Cards:** `0.5rem` (8px). Keeps table tiles compact and aligned.
- **Modals, Sheets, and Drawer Headers (`rounded-lg`):** `1rem` (16px). Softens larger interactive surfaces.
- **Floating Overlays & Hero Modals (`rounded-xl`):** `1.5rem` (24px).
- **Status Badges, Steppers, & Action Pills:** Full pill (`9999px`) for table identifiers (`Table 14`), order stage chips (`Appetizers`, `Mains`), and count badges.

## Components

### Buttons
- **Primary:** Filled Emerald (`#10b981`), high-contrast dark text (`#022c22` or `#ffffff`), bold font weight (`label-lg`), 8px border radius. Hover introduces brightness increase and 2px emerald halo.
- **Secondary:** Slate fill (`#1e293b`), border 1px solid `rgba(255, 255, 255, 0.12)`, text `#f8fafc`. Hover shifts background to `#334155`.
- **Destructive (Void / 86 Item):** Ghost outline with `#ef4444` text and border; transitions to filled `#ef4444` on hover/confirm.
- **Touch Targets:** All primary kitchen/POS action buttons enforce a minimum height of 48px.

### Chips & Table Status Badges
- Compact pill-shaped elements (`rounded-full`, 24px or 28px height) with semi-transparent tinted backgrounds:
  - **Available / Seated:** Emerald (`rgba(16, 185, 129, 0.15)` fill, `#10b981` border, `#34d399` text).
  - **Ordering / Bill Requested:** Amber (`rgba(245, 158, 11, 0.15)` fill, `#f59e0b` border, `#fbbf24` text).
  - **Kitchen Fired / Hold:** Indigo (`rgba(99, 102, 241, 0.15)` fill, `#6366f1` border, `#818cf8` text).
  - **86'd (Out of Stock):** Slate-muted with slash or red accent badge.

### Input Fields & Modifiers
- Background `#1e293b`, 1px border `rgba(255, 255, 255, 0.1)`, 8px radius.
- Height: 44px (48px on mobile). Focus state rings `#10b981` at 2px with zero displacement.
- Numeric steppers (seat counts, portion quantities) feature bold oversized `+` and `-` buttons (36px min width) for greasy or wet-finger operability.

### Cards & Table Floor Nodes
- **Floor Plan Card:** Grid cell showing Table Name, Waiter ID, Elapsed Time, and Total Amount. A 3px top border colored by status (Emerald/Amber/Indigo) defines state instantly without occupying layout space.
- **Menu Item Card (Diner View):** `#1e293b` container with top-flush image, typography in `#f8fafc`, nutritional and allergen micro-badges, and a high-contrast floating `+` add-button at the bottom-right.

### Order Ticket Drawer (Expo Screen)
- Vertical sticky stack with distinct receipt tear separation (`border-dashed 1px #334155`).
- Elapsed timer badge anchored top right with automated color shift: Slate (0-10m) -> Amber (11-20m) -> Red pulsing (21m+).
- Individual order items strikethrough upon single tap; long-press opens course-fire controls.